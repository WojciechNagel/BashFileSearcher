#!/bin/bash
(grep "\.iso" cdlinux.www.log | cut -d ' ' -f 7 | sed "s#.*/##" && grep "OK" cdlinux.ftp.log | cut -d '"' -f 2,4|sort|uniq|cut -d '"' -f 2|sed "s#.*/##"|grep "\.iso")| sort |uniq -c | sort -n | grep " cdlinux" | grep -oh ".*\.iso" --color=never

