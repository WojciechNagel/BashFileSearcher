#!/bin/bash
grep "OK" cdlinux.ftp.log | cut -d '"' -f 2,4|sort|uniq|cut -d '"' -f 2|sed "s#.*/##"|sort|uniq -c|sort -n| grep "\.iso" --color=never 
grep "\.iso" cdlinux.www.log | cut -d ' ' -f 7 | sed "s#.*/##" | sort | uniq -c | sort -n | grep " cdlinux" | grep -oh ".*\.iso" --color=never

